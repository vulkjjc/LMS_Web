<?php

$connection = mysqli_connect('localhost','root','','lms');

    if(!$connection)
    {
        die("database connection failed");
    }

?>